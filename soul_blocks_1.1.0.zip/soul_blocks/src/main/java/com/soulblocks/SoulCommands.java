package com.soulblocks;

import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.soulblocks.entity.GhostAbilities;
import com.soulblocks.entity.SoulBlockEntity;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.command.argument.UuidArgumentType;
import net.minecraft.entity.Entity;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;

import java.util.UUID;

public class SoulCommands {
    public static void register() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
                dispatcher.register(CommandManager.literal("soulblocks")
                        .then(CommandManager.literal("goto")
                                .then(CommandManager.argument("id", UuidArgumentType.uuid())
                                        .executes(SoulCommands::gotoOre)))));
    }

    private static int gotoOre(CommandContext<ServerCommandSource> ctx) throws CommandSyntaxException {
        ServerCommandSource source = ctx.getSource();
        ServerPlayerEntity player = source.getPlayerOrThrow();
        UUID id = UuidArgumentType.getUuid(ctx, "id");
        ServerWorld world = source.getWorld();

        Entity entity = world.getEntity(id);
        if (!(entity instanceof SoulBlockEntity ghost) || !player.getUuid().equals(ghost.getOwnerUuid())) {
            player.sendMessage(Text.literal("[Soul Block] That ghost is not around anymore."), false);
            return 0;
        }
        BlockPos target = ghost.getAlertTarget();
        if (target == null) {
            player.sendMessage(Text.literal("[Soul Block] That alert has expired."), false);
            return 0;
        }
        BlockPos spot = GhostAbilities.findSafeSpot(world, target);
        if (spot == null) {
            player.sendMessage(Text.literal("[Soul Block] I couldn't find a safe spot there."), false);
            ghost.clearAlertTarget();
            return 0;
        }
        player.teleport(world, spot.getX() + 0.5, spot.getY(), spot.getZ() + 0.5, player.getYaw(), player.getPitch());
        ghost.refreshPositionAndAngles(spot.getX() + 0.5, spot.getY() + 1.5, spot.getZ() + 0.5, ghost.getYaw(), ghost.getPitch());
        ghost.clearAlertTarget();
        return 1;
    }
}
