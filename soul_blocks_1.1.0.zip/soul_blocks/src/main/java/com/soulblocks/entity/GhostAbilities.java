package com.soulblocks.entity;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.world.World;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public final class GhostAbilities {
    public enum Kind { NONE, ORE_FINDER, TNT, FIRE, ICE, SLIME, FURNACE, GLOW }

    private static final Map<Block, List<Block>> ORES = new HashMap<>();

    static {
        ORES.put(Blocks.DIAMOND_BLOCK, List.of(Blocks.DIAMOND_ORE, Blocks.DEEPSLATE_DIAMOND_ORE));
        ORES.put(Blocks.IRON_BLOCK, List.of(Blocks.IRON_ORE, Blocks.DEEPSLATE_IRON_ORE));
        ORES.put(Blocks.GOLD_BLOCK, List.of(Blocks.GOLD_ORE, Blocks.DEEPSLATE_GOLD_ORE, Blocks.NETHER_GOLD_ORE));
        ORES.put(Blocks.EMERALD_BLOCK, List.of(Blocks.EMERALD_ORE, Blocks.DEEPSLATE_EMERALD_ORE));
        ORES.put(Blocks.COAL_BLOCK, List.of(Blocks.COAL_ORE, Blocks.DEEPSLATE_COAL_ORE));
        ORES.put(Blocks.LAPIS_BLOCK, List.of(Blocks.LAPIS_ORE, Blocks.DEEPSLATE_LAPIS_ORE));
        ORES.put(Blocks.REDSTONE_BLOCK, List.of(Blocks.REDSTONE_ORE, Blocks.DEEPSLATE_REDSTONE_ORE));
        ORES.put(Blocks.COPPER_BLOCK, List.of(Blocks.COPPER_ORE, Blocks.DEEPSLATE_COPPER_ORE));
        ORES.put(Blocks.NETHERITE_BLOCK, List.of(Blocks.ANCIENT_DEBRIS));
        ORES.put(Blocks.QUARTZ_BLOCK, List.of(Blocks.NETHER_QUARTZ_ORE));
    }

    private GhostAbilities() {
    }

    public static List<Block> oreTargets(Block block) {
        return ORES.get(block);
    }

    public static Kind kindOf(Block block) {
        if (ORES.containsKey(block)) return Kind.ORE_FINDER;
        if (block == Blocks.TNT) return Kind.TNT;
        if (block == Blocks.MAGMA_BLOCK) return Kind.FIRE;
        if (block == Blocks.ICE || block == Blocks.PACKED_ICE || block == Blocks.BLUE_ICE) return Kind.ICE;
        if (block == Blocks.SLIME_BLOCK) return Kind.SLIME;
        if (block == Blocks.FURNACE || block == Blocks.BLAST_FURNACE || block == Blocks.SMOKER) return Kind.FURNACE;
        if (block == Blocks.GLOWSTONE || block == Blocks.SEA_LANTERN) return Kind.GLOW;
        return Kind.NONE;
    }

    public static boolean isCombat(Kind kind) {
        return kind == Kind.TNT || kind == Kind.FIRE || kind == Kind.ICE || kind == Kind.SLIME;
    }

    /** Finds a safe standing spot (solid floor, 2 free blocks above) close to the given position, or null. */
    public static BlockPos findSafeSpot(World w, BlockPos center) {
        BlockPos best = null;
        double bestDist = Double.MAX_VALUE;
        for (BlockPos p : BlockPos.iterate(center.add(-4, -3, -4), center.add(4, 3, 4))) {
            BlockPos below = p.down();
            BlockState belowState = w.getBlockState(below);
            if (!belowState.isSideSolidFullSquare(w, below, Direction.UP)) continue;
            if (belowState.isOf(Blocks.MAGMA_BLOCK)) continue;
            if (!w.getBlockState(p).getCollisionShape(w, p).isEmpty()) continue;
            BlockPos above = p.up();
            if (!w.getBlockState(above).getCollisionShape(w, above).isEmpty()) continue;
            if (!w.getFluidState(p).isEmpty() || !w.getFluidState(above).isEmpty()) continue;
            double d = p.getSquaredDistance(center);
            if (d < bestDist) {
                bestDist = d;
                best = p.toImmutable();
            }
        }
        return best;
    }
}
