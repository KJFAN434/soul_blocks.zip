package com.soulblocks.entity;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ai.control.FlightMoveControl;
import net.minecraft.entity.ai.pathing.BirdNavigation;
import net.minecraft.entity.ai.pathing.EntityNavigation;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.data.DataTracker;
import net.minecraft.entity.data.TrackedData;
import net.minecraft.entity.data.TrackedDataHandlerRegistry;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.EndermanEntity;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.mob.PathAwareEntity;
import net.minecraft.entity.mob.WardenEntity;
import net.minecraft.entity.mob.ZombifiedPiglinEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.recipe.AbstractCookingRecipe;
import net.minecraft.recipe.RecipeEntry;
import net.minecraft.recipe.RecipeType;
import net.minecraft.recipe.input.SingleStackRecipeInput;
import net.minecraft.registry.Registries;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.ClickEvent;
import net.minecraft.text.MutableText;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;

public class SoulBlockEntity extends PathAwareEntity {
    private static final TrackedData<BlockState> BLOCK =
            DataTracker.registerData(SoulBlockEntity.class, TrackedDataHandlerRegistry.BLOCK_STATE);

    private UUID ownerUuid;

    // Ability state (not saved)
    private int attackCooldown = 0;
    private BlockPos alertTarget;
    private BlockPos lastAlerted;
    private int alertCooldownUntil = 0;
    private final Set<Long> rejected = new HashSet<>();

    public SoulBlockEntity(EntityType<? extends SoulBlockEntity> type, World world) {
        super(type, world);
        this.moveControl = new FlightMoveControl(this, 10, true);
        this.setNoGravity(true);
        this.setPersistent();
    }

    public static DefaultAttributeContainer.Builder createSoulAttributes() {
        return MobEntity.createMobAttributes()
                .add(EntityAttributes.GENERIC_MAX_HEALTH, 10.0)
                .add(EntityAttributes.GENERIC_FLYING_SPEED, 0.6)
                .add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.3);
    }

    @Override
    protected void initDataTracker(DataTracker.Builder builder) {
        super.initDataTracker(builder);
        builder.add(BLOCK, Blocks.STONE.getDefaultState());
    }

    @Override
    protected void initGoals() {
        this.goalSelector.add(1, new ChaseEnemyGoal(this));
        this.goalSelector.add(2, new FollowOwnerGoal(this));
    }

    @Override
    protected EntityNavigation createNavigation(World world) {
        return new BirdNavigation(this, world);
    }

    @Override
    public boolean handleFallDamage(float fallDistance, float damageMultiplier, DamageSource damageSource) {
        return false;
    }

    public BlockState getBlock() {
        return this.dataTracker.get(BLOCK);
    }

    public void setBlock(BlockState state) {
        this.dataTracker.set(BLOCK, state);
    }

    public void setOwner(UUID uuid) {
        this.ownerUuid = uuid;
    }

    public UUID getOwnerUuid() {
        return ownerUuid;
    }

    public PlayerEntity getOwner() {
        return ownerUuid == null ? null : this.getWorld().getPlayerByUuid(ownerUuid);
    }

    public BlockPos getAlertTarget() {
        return alertTarget;
    }

    public void clearAlertTarget() {
        alertTarget = null;
    }

    // ---------------------------------------------------------------- abilities

    @Override
    public void tick() {
        super.tick();
        if (this.getWorld().isClient) {
            return;
        }
        if (attackCooldown > 0) {
            attackCooldown--;
        }
        Block block = getBlock().getBlock();
        GhostAbilities.Kind kind = GhostAbilities.kindOf(block);

        switch (kind) {
            case FURNACE -> {
                if (this.age % 20 == 0) {
                    if (block == Blocks.BLAST_FURNACE) {
                        smeltNearby(RecipeType.BLASTING);
                    } else if (block == Blocks.SMOKER) {
                        smeltNearby(RecipeType.SMOKING);
                    } else {
                        smeltNearby(RecipeType.SMELTING);
                    }
                }
            }
            case ORE_FINDER -> {
                if (this.age % 60 == 0) {
                    scanForOre(GhostAbilities.oreTargets(block));
                }
            }
            case GLOW -> {
                if (this.age % 100 == 0) {
                    PlayerEntity owner = getOwner();
                    if (owner != null && this.squaredDistanceTo(owner) < 256.0) {
                        owner.addStatusEffect(new StatusEffectInstance(StatusEffects.NIGHT_VISION, 400, 0, true, false));
                    }
                }
            }
            default -> {
            }
        }
    }

    public boolean hasCombatAbility() {
        return GhostAbilities.isCombat(GhostAbilities.kindOf(getBlock().getBlock()));
    }

    public boolean canAttackNow() {
        return attackCooldown <= 0;
    }

    public LivingEntity findEnemy(PlayerEntity owner) {
        List<HostileEntity> list = this.getWorld().getEntitiesByClass(
                HostileEntity.class,
                owner.getBoundingBox().expand(12.0),
                e -> e.isAlive()
                        && !(e instanceof WardenEntity)
                        && !(e instanceof EndermanEntity)
                        && !(e instanceof ZombifiedPiglinEntity));
        HostileEntity best = null;
        double bestDist = Double.MAX_VALUE;
        for (HostileEntity e : list) {
            double d = this.squaredDistanceTo(e);
            if (d < bestDist) {
                bestDist = d;
                best = e;
            }
        }
        return best;
    }

    public void performAttack(LivingEntity target) {
        if (!(this.getWorld() instanceof ServerWorld sw)) {
            return;
        }
        GhostAbilities.Kind kind = GhostAbilities.kindOf(getBlock().getBlock());
        DamageSource source = sw.getDamageSources().mobAttack(this);
        attackCooldown = 40;

        switch (kind) {
            case TNT -> {
                attackCooldown = 60;
                target.damage(source, 5.0f);
                // power 0 = sound + particles only, no block damage and no damage to the owner
                sw.createExplosion(null, target.getX(), target.getBodyY(0.5), target.getZ(), 0.0f, World.ExplosionSourceType.NONE);
            }
            case FIRE -> {
                target.damage(source, 1.0f);
                target.setOnFireFor(4);
                sw.spawnParticles(ParticleTypes.FLAME, target.getX(), target.getBodyY(0.5), target.getZ(), 8, 0.2, 0.3, 0.2, 0.02);
            }
            case ICE -> {
                target.damage(source, 1.0f);
                target.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 80, 2));
                sw.spawnParticles(ParticleTypes.SNOWFLAKE, target.getX(), target.getBodyY(0.5), target.getZ(), 10, 0.2, 0.3, 0.2, 0.02);
            }
            case SLIME -> {
                target.damage(source, 1.0f);
                target.takeKnockback(1.2, this.getX() - target.getX(), this.getZ() - target.getZ());
                sw.spawnParticles(ParticleTypes.ITEM_SLIME, target.getX(), target.getBodyY(0.5), target.getZ(), 8, 0.2, 0.3, 0.2, 0.02);
            }
            default -> {
            }
        }
    }

    private <T extends AbstractCookingRecipe> void smeltNearby(RecipeType<T> type) {
        ServerWorld sw = (ServerWorld) this.getWorld();
        List<ItemEntity> items = sw.getEntitiesByClass(
                ItemEntity.class,
                this.getBoundingBox().expand(3.0),
                i -> i.isAlive() && !i.getStack().isEmpty());
        for (ItemEntity item : items) {
            ItemStack stack = item.getStack();
            Optional<RecipeEntry<T>> match = sw.getRecipeManager()
                    .getFirstMatch(type, new SingleStackRecipeInput(stack), sw);
            if (match.isEmpty()) {
                continue;
            }
            ItemStack result = match.get().value().getResult(sw.getRegistryManager()).copy();
            if (result.isEmpty()) {
                continue;
            }
            int total = result.getCount() * stack.getCount();
            result.setCount(Math.min(total, result.getMaxCount()));
            item.setStack(result);
            sw.spawnParticles(ParticleTypes.FLAME, item.getX(), item.getY() + 0.2, item.getZ(), 6, 0.1, 0.1, 0.1, 0.01);
            break; // one stack per pass
        }
    }

    private void scanForOre(List<Block> targets) {
        PlayerEntity owner = getOwner();
        if (targets == null || owner == null || this.age < alertCooldownUntil) {
            return;
        }
        World w = this.getWorld();
        BlockPos origin = this.getBlockPos();
        for (BlockPos p : BlockPos.iterate(origin.add(-10, -10, -10), origin.add(10, 10, 10))) {
            BlockState state = w.getBlockState(p);
            if (!targets.contains(state.getBlock())) {
                continue;
            }
            BlockPos pos = p.toImmutable();
            if (pos.equals(lastAlerted) || rejected.contains(pos.asLong())) {
                continue;
            }
            if (GhostAbilities.findSafeSpot(w, pos) == null) {
                if (rejected.size() > 500) {
                    rejected.clear();
                }
                rejected.add(pos.asLong());
                continue;
            }
            alertTarget = pos;
            lastAlerted = pos;
            alertCooldownUntil = this.age + 400;

            Style buttonStyle = Style.EMPTY
                    .withColor(Formatting.AQUA)
                    .withUnderline(true)
                    .withClickEvent(new ClickEvent(ClickEvent.Action.RUN_COMMAND,
                            "/soulblocks goto " + this.getUuidAsString()));
            MutableText message = Text.literal("[Soul Block] I found ")
                    .append(state.getBlock().getName())
                    .append(Text.literal(" nearby! "))
                    .append(Text.literal("[Follow me]").setStyle(buttonStyle));
            owner.sendMessage(message, false);
            return;
        }
    }

    // ---------------------------------------------------------------- interaction / saving

    // Sneak + right click with an empty hand: turn the ghost back into a block item.
    @Override
    public ActionResult interactMob(PlayerEntity player, Hand hand) {
        if (player.isSneaking() && player.getStackInHand(hand).isEmpty()) {
            if (!this.getWorld().isClient) {
                this.dropStack(new ItemStack(getBlock().getBlock()));
                this.discard();
            }
            return ActionResult.SUCCESS;
        }
        return super.interactMob(player, hand);
    }

    @Override
    public void onDeath(DamageSource source) {
        if (!this.getWorld().isClient) {
            this.dropStack(new ItemStack(getBlock().getBlock()));
        }
        super.onDeath(source);
    }

    @Override
    public void writeCustomDataToNbt(NbtCompound nbt) {
        super.writeCustomDataToNbt(nbt);
        nbt.putString("GhostBlock", Registries.BLOCK.getId(getBlock().getBlock()).toString());
        if (ownerUuid != null) {
            nbt.putUuid("Owner", ownerUuid);
        }
    }

    @Override
    public void readCustomDataFromNbt(NbtCompound nbt) {
        super.readCustomDataFromNbt(nbt);
        if (nbt.contains("GhostBlock")) {
            Identifier id = Identifier.tryParse(nbt.getString("GhostBlock"));
            if (id != null) {
                Block block = Registries.BLOCK.get(id);
                setBlock(block.getDefaultState());
            }
        }
        if (nbt.containsUuid("Owner")) {
            ownerUuid = nbt.getUuid("Owner");
        }
    }
}
