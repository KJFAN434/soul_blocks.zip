package com.soulblocks.entity;

import net.minecraft.entity.ai.goal.Goal;
import net.minecraft.entity.player.PlayerEntity;

import java.util.EnumSet;

public class FollowOwnerGoal extends Goal {
    private final SoulBlockEntity mob;

    public FollowOwnerGoal(SoulBlockEntity mob) {
        this.mob = mob;
        this.setControls(EnumSet.of(Goal.Control.MOVE));
    }

    @Override
    public boolean canStart() {
        return mob.getOwner() != null;
    }

    @Override
    public boolean shouldContinue() {
        return mob.getOwner() != null;
    }

    @Override
    public void tick() {
        PlayerEntity owner = mob.getOwner();
        if (owner == null) {
            return;
        }
        double distSq = mob.squaredDistanceTo(owner);
        if (distSq > 576.0) { // more than 24 blocks away: teleport next to the player
            mob.refreshPositionAndAngles(owner.getX(), owner.getY() + 1.5, owner.getZ(), mob.getYaw(), mob.getPitch());
        } else if (distSq > 9.0) { // more than 3 blocks away: fly towards the player
            mob.getMoveControl().moveTo(owner.getX(), owner.getY() + 1.5, owner.getZ(), 1.0);
        }
        mob.getLookControl().lookAt(owner, 30.0f, 30.0f);
    }
}
