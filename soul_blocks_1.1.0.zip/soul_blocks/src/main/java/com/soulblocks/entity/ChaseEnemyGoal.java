package com.soulblocks.entity;

import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ai.goal.Goal;
import net.minecraft.entity.player.PlayerEntity;

import java.util.EnumSet;

public class ChaseEnemyGoal extends Goal {
    private final SoulBlockEntity mob;
    private LivingEntity target;

    public ChaseEnemyGoal(SoulBlockEntity mob) {
        this.mob = mob;
        this.setControls(EnumSet.of(Goal.Control.MOVE));
    }

    @Override
    public boolean canStart() {
        if (!mob.hasCombatAbility() || mob.age % 10 != 0) {
            return false;
        }
        PlayerEntity owner = mob.getOwner();
        if (owner == null) {
            return false;
        }
        target = mob.findEnemy(owner);
        return target != null;
    }

    @Override
    public boolean shouldContinue() {
        PlayerEntity owner = mob.getOwner();
        return target != null && target.isAlive() && owner != null
                && mob.squaredDistanceTo(target) < 400.0 && mob.squaredDistanceTo(owner) < 576.0;
    }

    @Override
    public void tick() {
        if (target == null) {
            return;
        }
        mob.getMoveControl().moveTo(target.getX(), target.getY() + target.getHeight() / 2.0, target.getZ(), 1.3);
        mob.getLookControl().lookAt(target, 30.0f, 30.0f);
        if (mob.squaredDistanceTo(target) < 3.0 && mob.canAttackNow()) {
            mob.performAttack(target);
        }
    }

    @Override
    public void stop() {
        target = null;
    }
}
