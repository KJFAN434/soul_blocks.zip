package com.soulblocks;

import net.fabricmc.api.ModInitializer;

public class SoulBlocks implements ModInitializer {
    public static final String MOD_ID = "soul_blocks";

    @Override
    public void onInitialize() {
        ModItems.register();
        ModEntities.register();
        SoulCommands.register();
    }
}
