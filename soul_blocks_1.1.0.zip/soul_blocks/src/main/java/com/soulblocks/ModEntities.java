package com.soulblocks;

import com.soulblocks.entity.SoulBlockEntity;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

public class ModEntities {
    public static final EntityType<SoulBlockEntity> SOUL_BLOCK = Registry.register(
            Registries.ENTITY_TYPE,
            Identifier.of(SoulBlocks.MOD_ID, "soul_block"),
            EntityType.Builder.create(SoulBlockEntity::new, SpawnGroup.CREATURE)
                    .dimensions(0.4f, 0.4f)
                    .maxTrackingRange(8)
                    .build("soul_block"));

    public static void register() {
        FabricDefaultAttributeRegistry.register(SOUL_BLOCK, SoulBlockEntity.createSoulAttributes());
    }
}
