package com.soulblocks.client;

import com.soulblocks.entity.SoulBlockEntity;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.block.BlockRenderManager;
import net.minecraft.client.render.entity.EntityRenderer;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.texture.SpriteAtlasTexture;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.RotationAxis;

public class SoulBlockRenderer extends EntityRenderer<SoulBlockEntity> {
    private final BlockRenderManager blockRenderManager;

    public SoulBlockRenderer(EntityRendererFactory.Context context) {
        super(context);
        this.blockRenderManager = context.getBlockRenderManager();
        this.shadowRadius = 0.15f;
    }

    @Override
    public void render(SoulBlockEntity entity, float yaw, float tickDelta, MatrixStack matrices,
                       VertexConsumerProvider vertexConsumers, int light) {
        float time = entity.age + tickDelta;
        float bob = (float) Math.sin(time * 0.1f) * 0.06f;

        matrices.push();
        matrices.translate(0.0, 0.1 + bob, 0.0);
        matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(time * 2.0f));
        matrices.scale(0.4f, 0.4f, 0.4f);
        matrices.translate(-0.5, 0.0, -0.5);
        blockRenderManager.renderBlockAsEntity(entity.getBlock(), matrices, vertexConsumers, light, OverlayTexture.DEFAULT_UV);
        matrices.pop();

        super.render(entity, yaw, tickDelta, matrices, vertexConsumers, light);
    }

    @Override
    public Identifier getTexture(SoulBlockEntity entity) {
        return SpriteAtlasTexture.BLOCK_ATLAS_TEXTURE;
    }
}
