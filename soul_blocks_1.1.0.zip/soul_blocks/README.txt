SOUL BLOCKS (Fabric 1.21.1)

REQUIREMENTS: Java 21 JDK, IntelliJ IDEA (Community is fine)

BUILD:
1. Unzip this folder.
2. Open it in IntelliJ IDEA (File > Open > select the soul_blocks folder). Let Gradle import finish.
3. Open the Gradle panel (elephant icon, right side) > Tasks > build > build (double click).
4. Your mod file: build/libs/soul_blocks-1.0.0.jar  (NOT the "-sources" one)
5. Put it in the mods folder together with Fabric API for 1.21.1.

USE IN GAME:
- Smelt Soul Sand in a Blast Furnace -> Soul
- Right click a block with Soul -> tiny floating ghost block that follows you
- Sneak + right click it with an empty hand -> get the block back

BUILD WITHOUT A PC (GitHub):
1. Create a free GitHub account and a new repository.
2. Upload all files of this project, keeping the folder structure
   (the hidden .github/workflows/build.yml file is the important one).
3. Open the "Actions" tab > latest "build" run > download "soul_blocks_jar" at the bottom.
4. Unzip it: the jar WITHOUT "-sources" in its name is the mod.

ABILITIES (v1.1.0):
- Diamond/Iron/Gold/Emerald/Coal/Lapis/Redstone/Copper/Netherite/Quartz block: finds matching ore nearby, sends a clickable [Follow me] chat message
- TNT block: small explosion hits (no block damage) on hostile mobs
- Magma block: sets enemies on fire. Ice/Packed Ice/Blue Ice: slows enemies. Slime block: knocks enemies back
- Furnace/Blast Furnace/Smoker: smelts nearby dropped items without fuel
- Glowstone/Sea Lantern: gives you night vision
